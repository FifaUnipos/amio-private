package com.fifapay.unipos

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
